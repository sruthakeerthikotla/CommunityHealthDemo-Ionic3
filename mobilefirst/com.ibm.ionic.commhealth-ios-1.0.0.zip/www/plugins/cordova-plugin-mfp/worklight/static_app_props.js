// This is a generated file. Do not edit. See application-descriptor.xml.
// WLClient configuration variables.
console.log("Running static_app_props.js...");
var WL = WL ? WL : {};
WL.StaticAppProps = { APP_ID: 'com.ibm.ionic.commhealth',
  APP_VERSION: '1.0.0',
  WORKLIGHT_PLATFORM_VERSION: '8.0.0.00-20180227-121751',
  WORKLIGHT_NATIVE_VERSION: '719857146',
  LANGUAGE_PREFERENCES: 'en',
  ENVIRONMENT: 'iphone',
  WORKLIGHT_ROOT_URL: '/apps/services/api/com.ibm.ionic.commhealth/iphone/',
  APP_SERVICES_URL: '/apps/services/',
  APP_DISPLAY_NAME: 'Community Health',
  LOGIN_DISPLAY_TYPE: 'embedded',
  mfpClientCustomInit: false,
  MESSAGES_DIR: 'plugins/cordova-plugin-mfp/worklight/messages' };